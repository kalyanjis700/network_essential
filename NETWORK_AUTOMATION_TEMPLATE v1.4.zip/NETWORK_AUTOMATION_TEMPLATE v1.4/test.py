# from crypt import methods
# from shutil import register_unpack_format
import xlrd
from flask import Flask, render_template,request
from pysnmp.hlapi import *
# from urllib3 import Retry
from netmiko import ConnectHandler
from netmiko.ssh_autodetect import SSHDetect
from netmiko.ssh_dispatcher import ConnectHandler
import subprocess


remote_device = {'device_type': 'autodetect','host': '10.116.10.5','username': 'indranil','password': 'P@ssw0rd'}
guesser = SSHDetect(**remote_device)
vendor = guesser.autodetect()

print(vendor)
