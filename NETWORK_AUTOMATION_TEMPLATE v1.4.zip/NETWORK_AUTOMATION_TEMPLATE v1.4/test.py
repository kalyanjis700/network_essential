import requests

url = "https://192.168.0.8:443/mgmt/tm/ltm/pool/http_pool/stats"
pload = {'username':'admin','password':'admin'}
response = requests.get(url, data = pload, verify=False)
print(response.text)