// document.write(
//     `<header class="em-c-header em-c-header--blue" role="banner">
//         <div class="em-l-container em-c-header__inner">
//             <div class="em-c-header__body">
//                 <div class="em-c-header__title-container">
//                     <h2 class="em-c-header__title">
//                         <a href="/" rel="home" class="em-c-header__title-link">FI GATEWAY</a>
//                     </h2>
//                 </div>
//                 <!-- end em-c-header__left -->
//                 <button class="em-c-btn em-c-btn--small em-c-btn--inverted em-c-header__nav-btn em-js-nav-trigger">
//                     <div class="em-c-btn__inner">
//                     <svg class="em-c-icon em-c-icon--small em-c-btn__icon em-js-btn-icon" data-em-btn-toggle-text="Close" data-em-icon-path="/static/images/em-icons.svg">
//                         <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/static/images/em-icons.svg#hamburger"></use>
//                     </svg>
//                     <svg class="em-c-icon em-c-icon--small em-c-btn__icon em-u-is-hidden em-js-btn-swap-icon" data-em-icon-path="/static/images/em-icons.svg">
//                         <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/static/images/em-icons.svg#x-filled"></use>
//                     </svg>
//                     <span class="em-c-btn__text em-js-btn-label">Menu</span>
//                     </div>
//                 </button>
//                 <!-- end em-c-btn -->
//                 <div class="em-c-header__nav-container em-js-nav-panel">
//                     <nav id="nav" class="em-c-primary-nav" role="navigation">
//                     <ul class="em-c-primary-nav__list">
//                         <li class="em-c-primary-nav__item ">
//                             <a href="/" class="em-c-primary-nav__link em-is-current ">Home</a>
//                         <!--end em-c-primary-nav__link-->
//                         </li>
//                         <!-- end em-c-nav__list__item -->

//                         <li class="em-c-primary-nav__item ">
//                             <a href="/internal" class="em-c-primary-nav__link em-is-current ">Gateway Internal</a>
//                         <!--end em-c-primary-nav__link-->
//                         </li>
//                         <!-- end em-c-nav__list__item -->

                        
//                     </ul>
//                     <!-- end em-c-nav__list -->
//                     </nav>
//                     <!-- end em-c-nav -->
//                 </div>
//                 <!-- end em-c-header__nav -->
//             </div>
//             <!-- end em-c-header__body -->
//         </div>
//         <!-- end em-l-container -->
//     </header>`
// )
fetch("/header_external")
    .then(response => {
        return response.text()
    })
    .then(data => {
        document.getElementById("external_header").innerHTML = data
    })

function permission(data) {
    let user_session = JSON.parse(data)
    console.log(user_session.roles)

    if (!user_session.roles.includes("User")) {
        let action = document.getElementsByClassName("em-c-primary-nav__link")[1]
        console.log(action)
        action.setAttribute("style", "pointer-events: none; color: #bfbfbf;")
    }
}