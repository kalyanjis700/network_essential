from flask import Flask, render_template, request, redirect, url_for, make_response, jsonify, session
import os
import json
import requests
# from flask_mysqldb import MySQL
# import mysql.connector
# import yaml
# import uuid
# import sys
# import tracebacks
# from flask_cors import CORS
# from datetime import datetime
# from jinja2 import Environment, PackageLoader, select_autoescape
# import smtplib, ssl
# from email.message import EmailMessage
# from html2text import html2text
# from flask_oidc import OpenIDConnect
# from flask_dance.contrib.azure import make_azure_blueprint, azure
# from flask_session import Session
# import uuid
# import msal
# import app_config

app = Flask(__name__, static_folder='static')

@app.route('/', methods=['GET'])
def main_page_route():
    return render_template('index.html')

@app.route('/SECOND_PAGE', methods=['GET'])
def second_page_route():
    return render_template('second_page.html')

@app.route('/THIRD_PAGE', methods=['GET'])
def third_page_route():
    return render_template('third_page.html')

@app.route('/HOME', methods=['GET'])
def home_page_route():
    return render_template('home.html')

@app.route('/header_external', methods=['GET'])
def int_header():
    return render_template('header_external.html')

# @app.route('/footer_site', methods=['GET'])
# def site_footer():
#     return render_template('footer_site.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, threaded=True)
