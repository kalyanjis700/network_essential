from netmiko import ConnectHandler
from netmiko.ssh_autodetect import SSHDetect
from netmiko.ssh_dispatcher import ConnectHandler
remote_device = {'device_type': 'autodetect','host': '192.168.0.14','username': 'root','password': 'default'}
guesser = SSHDetect(**remote_device)
vendor = guesser.autodetect()
remote_device['device_type'] = vendor
net_connect = ConnectHandler(**remote_device)
output = net_connect.send_command("tmsh show sys version")
print(output)


            