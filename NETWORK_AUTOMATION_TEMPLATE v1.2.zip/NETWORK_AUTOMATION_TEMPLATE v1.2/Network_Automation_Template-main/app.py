# from crypt import methods
# from shutil import register_unpack_format
from flask import Flask, render_template,request
# from urllib3 import Retry
app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/home')
def homeretrun():
    return render_template('index.html')

@app.route('/services')
def services():
    return render_template('services.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/inventory')
def inventory():
    return render_template('inventory.html')

@app.route('/result', methods = ["POST", "GET"])
def result():
    # output = request.form.to_dict()
    # devicename = output['devicename']
    # return render_template('inventory.html', devicename= devicename, Login-ID = Login-ID, password = Password)
    result = request.form.to_dict()
    return render_template('inventory.html', result= result)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port= '8080', debug=True , threaded=True)

