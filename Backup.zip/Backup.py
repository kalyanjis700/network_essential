#"python version should be more than 3.x"
#"pip install netmiko"
from netmiko import ConnectHandler
import getpass

USERNAME = input("login as: ")# "username"
PASSWORD = getpass.getpass("Login_password: ")#"password"

error = open("connection_Error", 'a')

filename = "devicelist.txt"
with open (filename , 'r') as f:
    command =f.read().splitlines()

for device in command:
    Capture = open(device, 'a')
    try:
        print('Connecting to ' + str(device))
        net_connect = ConnectHandler(device_type='cisco_ios', ip=device, username=USERNAME, password=PASSWORD, secret=PASSWORD, port=22)
        net_connect.enable()
        print("connection successfull to " + device)
        net_connect.send_command("terminal lenth 0")
        Capture.write("Backup for Device " + device + '\n')
        runningconfig = net_connect.send_command("show run")
        #asd = net_connect.send_command("give your command")
        Capture.write(runningconfig +'\n')
        #Capture.write(asd +'\n')
    except:
        print('connection is not successful To device : ' + str(device))
        ERROR = ('connection is not successful To device : ' + str(device))
        error.write(ERROR + '\n' + '\n')

input('Operation Completed!!!')
